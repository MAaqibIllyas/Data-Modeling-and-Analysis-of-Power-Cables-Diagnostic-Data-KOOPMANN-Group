import shutil
import os
import time

# Directory address:

path = "D:\\Reports\\"
path_excel = "D:\\ExcelMacros\\"

# !!! Before running the macro, change the PDF
#source path in the Convert.xlsm file !!! 

# For all pdf in folder execute following command 
# PDFData runs the update of excel file; 
# The data is stored in folders with the file name.

for root, dirs, files in os.walk(path):  
    for filename in files:  
        if (root == path) & ((filename)[-3:] == "pdf"):  
            print ((path + filename))
            shutil.copyfile((path + filename), path_excel + \
            "\\Example.pdf") #Copy PDF for extract data
            os.startfile(path_excel + "\\PDFData.xlsm")
            time.sleep(10)
            os.startfile(path_excel + "\\Convert.xlsm")
            time.sleep(20)
            #Folder exist?
            #If the folder does not exist, create a folder
            if os.path.exists((path + filename[0:-4])) != True: 
              os.mkdir((path + filename[0:-4]))                 
            shutil.copyfile( path_excel + \
            "\\Export.xlsx", (path + filename[0:-4]) + "\\Export.xlsx")